package run;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LoginEvent implements Serializable
{
    private static final long serialVersionUID = 4611686018427387904L;
    
    private long id;
    private String name;
    private long score;
    private long status;
    private long order;
    private Long timestamp;
}
