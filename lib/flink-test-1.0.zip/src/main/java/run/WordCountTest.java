package run;

/**
 * **************************************************************************************************
 * ProjectName   ：  flink-test
 * Package       ：  run
 * ClassName     ：  WordCountTest
 * CreateTime    ：  2023-08-10 19:55
 * Author        ：  Issac_Al
 * Email         ：  IssacAl@qq.com
 * IDE           ：  IntelliJ IDEA 2020.3.4
 * Version       ：  1.0
 * CodedFormat   ：  utf-8
 * Description   ：  Java Class
 * **************************************************************************************************
 */

public class WordCountTest
{
}
