package run;

import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.cep.CEP;
import org.apache.flink.cep.PatternStream;
import org.apache.flink.cep.functions.PatternProcessFunction;
import org.apache.flink.cep.pattern.Pattern;
import org.apache.flink.cep.pattern.conditions.SimpleCondition;
import org.apache.flink.core.fs.FileSystem;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.KeyedStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.util.Collector;

import java.time.Duration;
import java.util.List;
import java.util.Map;

@Slf4j
public class CepTest
{
    private static final String PATTERN_START = "start";
    private static final String PATTERN_MIDDLE = "middle";
    private static final String PATTERN_END = "end";
    
    
    public static void main(String[] args) throws Exception
    {
        // 获取运行环境
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        
        // 添加数据源
        DataStreamSource<LoginEvent> loginEventDataStreamSource = env.addSource(new LoginSource());
        SingleOutputStreamOperator<LoginEvent> dataSource = loginEventDataStreamSource.uid("DataSource").name("DataSource");
        
        WatermarkStrategy<LoginEvent> loginEventWatermarkStrategy = WatermarkStrategy.<LoginEvent>forBoundedOutOfOrderness(Duration.ofSeconds(5))
            .withTimestampAssigner((LoginEvent event, long timestamp) -> event.getTimestamp());
        
        SingleOutputStreamOperator<LoginEvent> loginEventSingleOutputStreamOperator = dataSource.assignTimestampsAndWatermarks(loginEventWatermarkStrategy);
        SingleOutputStreamOperator<LoginEvent> streamOperator = loginEventSingleOutputStreamOperator.uid("WaterMark").name("WaterMark");
        
        KeyedStream<LoginEvent, Long> loginEventIntegerKeyedStream = streamOperator.keyBy(LoginEvent::getId);
        
        SimpleCondition<LoginEvent> condition1 = new SimpleCondition<LoginEvent>()
        {
            @Override
            public boolean filter(LoginEvent value)
            {
                return value.getStatus() == 0;
            }
        };
        
        SimpleCondition<LoginEvent> condition2 = new SimpleCondition<LoginEvent>()
        {
            @Override
            public boolean filter(LoginEvent value)
            {
                return value.getId() == 103;
            }
        };
        
        SimpleCondition<LoginEvent> condition3 = new SimpleCondition<LoginEvent>()
        {
            @Override
            public boolean filter(LoginEvent value)
            {
                return value.getStatus() == -1;
            }
        };
        
        Pattern<LoginEvent, LoginEvent> pattern = Pattern.<LoginEvent>begin(PATTERN_START).where(condition1)
            .next(PATTERN_MIDDLE).where(condition2)
            .next(PATTERN_END).where(condition3)
            .within(Time.seconds(5));
        
        PatternStream<LoginEvent> patternStream = CEP.pattern(loginEventIntegerKeyedStream, pattern);
        
        PatternProcessFunction<LoginEvent, Map<String, List<LoginEvent>>> patternProcessFunction = new PatternProcessFunction<LoginEvent, Map<String, List<LoginEvent>>>()
        {
            @Override
            public void processMatch(Map<String, List<LoginEvent>> map, Context context, Collector<Map<String, List<LoginEvent>>> collector)
            {
                collector.collect(map);
            }
        };
        
        SingleOutputStreamOperator<Map<String, List<LoginEvent>>> mapSingleOutputStreamOperator = patternStream.process(patternProcessFunction);
        SingleOutputStreamOperator<Map<String, List<LoginEvent>>> outputStreamOperator = mapSingleOutputStreamOperator.uid("FlinkCep").name("FlinkCep");
    
        outputStreamOperator.print("Result ===>>").uid("OutputConsole").name("OutputConsole");
    
        String filePath;
        if (args.length > 1)
        {
            ParameterTool tool = ParameterTool.fromArgs(args);
            filePath = tool.get("path");
        } else if (args.length == 1)
        {
            filePath = args[0];
        } else
        {
            filePath = "data.txt";
        }
    
        log.error("FilePath = {}", filePath);
        outputStreamOperator.writeAsText(filePath, FileSystem.WriteMode.OVERWRITE).uid("OutputFile").name("OutputFile");
        
        log.warn("ExecutionPlan =============> \n{} \n", env.getExecutionPlan());
        env.execute("Flink CEP Test ...... ");
    }
}
