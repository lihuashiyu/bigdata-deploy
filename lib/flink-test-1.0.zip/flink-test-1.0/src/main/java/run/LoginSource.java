package run;

import lombok.extern.slf4j.Slf4j;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.source.RichSourceFunction;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

@Slf4j
public class LoginSource extends RichSourceFunction<LoginEvent>
{
    List<Integer> idList;
    List<String> nameList;
    List<Integer> statusList;
    List<Integer> scoreList;
    
    Random random;
    Boolean isRunning;
    
    
    @Override
    public void open(Configuration parameters) throws Exception
    {
        super.open(parameters);
        
        idList = Arrays.asList(102, 103, 104, 105, 106, 107);
        nameList = Arrays.asList("王二", "张三", "李四", "马五", "赵六", "田七");
        scoreList = Arrays.asList(30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90);
        statusList = Arrays.asList(-1, 0, 1);
        
        random = new Random();
        isRunning = true;
    }
    
    
    @Override
    public void run(SourceContext<LoginEvent> ctx) throws Exception
    {
        long startTime = System.currentTimeMillis();
        long sleepTime = 10L;
        
        for (int i = 0; i < 1000; i++)
        {
            int index = random.nextInt(5);
            
            int userId = idList.get(index);
            String userName = nameList.get(index);
            
            int score = scoreList.get(random.nextInt(12));
            
            Integer status = statusList.get(random.nextInt(2));
            
            long loginTime = System.currentTimeMillis();
            long order = (loginTime - startTime) / sleepTime;
            
            int different = random.nextInt(5000);
            
            ctx.collect(new LoginEvent(userId, userName, score, status, order, loginTime));
            
            TimeUnit.MILLISECONDS.sleep(sleepTime);
        }
    }
    
    
    @Override
    public void cancel()
    {
        isRunning = false;
        
        idList = new ArrayList<>();
        nameList = new ArrayList<>();
        scoreList = new ArrayList<>();
        statusList = new ArrayList<>();
    }
}
